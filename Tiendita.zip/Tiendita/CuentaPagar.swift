//
//  ViewController.swift
//  Tiendita
//
//  Created by Macbook on 3/14/19.
//  Copyright © 2019 dixLab. All rights reserved.
//

import UIKit

class CuentaPagar: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var TotalCuenta: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        TotalCuenta.text = "total a pagar: $\(String(CuentaTotal))"
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ListaProducto.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let CellIdenti = "CeldaCuenta"
        let Cell = tableView.dequeueReusableCell(withIdentifier: CellIdenti,for: indexPath) as! TableView2
        Cell.textLabel?.text = ListaProducto[indexPath.row].nombre
        Cell.cantidadLabel.text = String(ListaProducto[indexPath.row].cantidad)
        Cell.precioLabel.text = "$\(String(ListaProducto[indexPath.row].precioTotal))"
        return Cell
    }
    
    @IBAction func PagarCuenta(_ sender: UIButton){
        let menu = UIAlertController(title: "Cuenta Pagada", message: "Gracias por su compra vuelva pronto", preferredStyle: .alert)
        let Aceptar = UIAlertAction(title: "Listo", style: true, handler: nil)
        menu.addAction(Aceptar)
        present(menu, animated: true, completion: nil)
        
    }


}
