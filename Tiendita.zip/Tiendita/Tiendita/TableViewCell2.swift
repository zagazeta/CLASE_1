//
//  TableViewCell2.swift
//  Tiendita
//
//  Created by Macbook on 3/14/19.
//  Copyright © 2019 dixLab. All rights reserved.
//

import UIKit

class TableViewCell2: UITableViewCell {
    @IBOutlet var cantidadLabel: UILabel
    @IBOutlet var precioLabel: UILabel
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
