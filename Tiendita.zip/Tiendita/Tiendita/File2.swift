//
//  File2.swift
//  Tiendita
//
//  Created by Macbook on 3/14/19.
//  Copyright © 2019 dixLab. All rights reserved.
//

import Foundation

import UIKit

struct ProductoComprado {
    var nombre: String
    var precioTotal: Double
    var cantidad: Int
}

var CuentaTotal: Double = 0.0
var ListaProducto: [ProductoComprado] = []


