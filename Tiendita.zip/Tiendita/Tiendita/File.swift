//
//  File.swift
//  Tiendita
//
//  Created by Macbook on 3/14/19.
//  Copyright © 2019 dixLab. All rights reserved.
//

import Foundation

struct Producto {
    
    var nombre: String
    var precio: Double
    var contenido: String
    var imagen: String
}

var index=0

let tequila = Producto(nombre: "Jimador", precio: 600.00 , contenido: "Regalo Jima Crist rep 200 ml", imagen: "ji")

let whisky = Producto(nombre: "Johnie Walker", precio: 665.00, contenido: "Black Lable escocés 12 años 750 ml", imagen: "la")

var AguaBendita = [tequila, whisky]


