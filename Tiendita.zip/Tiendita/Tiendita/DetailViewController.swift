//
//  DetailViewController.swift
//  Tiendita
//
//  Created by Macbook on 3/14/19.
//  Copyright © 2019 dixLab. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var imagenDetail: UIImageView!
    @IBOutlet weak var etiqueta: UILabel!
    @IBOutlet weak var descripcion: UILabel!
    @IBOutlet weak var cantProducto: UITextField!
    
    var precioPagar: Double = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()

        etiqueta.text = AguaBendita[index].nombre
        imagenDetail.image = UIImage(named: AguaBendita[index].imagen)
        descripcion.text = AguaBendita[index]
        
    }
    

    @IBAction func AgregarCarrito(_sender: Any){
        
        if cantProductos.text! = ""{
            
            let optionMenu = UIAlertController(title: "Licores La Esperanza", message: "Los mejores licores, vinos, tequilas...del pais", preferredStyle: .alert)
            let OkAction = UIAlertAction(title: "Ok",style: .default, handler: nil)
            optionMenu.addAction(OkAction)
            present(optionMenu, animated: true, completion: nil)
        }else {
            precioPagar = Double(cantProducto.text!) * AguaBendita[index].precio
            let optionMenu = UIAlertController(title: "Agregar Al Carrito", message: "EL precio a pagar es: $\(precioPagar) ¿Desea Continuar?", preferredStyle: .alert)
            let yesAction = UIAlertAction(title: "Si", style: .default, handler: {(action: UIAlertAction)-> Void in
                CuentaTotal = CuentaTotal + self.precioPagar
                let newDiscList = ProductoComprado(nombre: AguaBendita[index].nombre, precioTotal: self.precioPagar, cantidad: Int(self.cantProducto.text!)!)
                ListaProducto.append(newDiscList)
            })
            let noAction = UIAlertAction(title: "NO", style: .cancel, handler: nil)
            optionMenu.addAction(yesAction)
            optionMenu.addAction(noAction)
            present(optionMenu, animated: true, completion: nil)
        }
    }
}
