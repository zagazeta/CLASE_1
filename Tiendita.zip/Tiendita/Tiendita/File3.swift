//
//  File3.swift
//  Tiendita
//
//  Created by Macbook on 3/14/19.
//  Copyright © 2019 dixLab. All rights reserved.
//

import Foundation

class CuentaPagar: UIViewController, UITableViewDelegate, UITableDataSource{
    
    <#code#>
}
