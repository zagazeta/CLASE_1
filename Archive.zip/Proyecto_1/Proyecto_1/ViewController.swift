//
//  ViewController.swift
//  Proyecto_1
//
//  Created by Usuario invitado on 2/5/19.
//  Copyright © 2019 ioslab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var etiqueta: UILabel!
    
    @IBOutlet weak var caja: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
   
    
    @IBAction func boton(_ sender: UIButton) {
        if let texto=caja.text {
            print(texto)
            etiqueta.text=texto
            
        }
    }
    
}

