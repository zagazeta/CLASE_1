import UIKit

//Optionals
//NIL

var name: String? = nil   //Solo si estamos seguros de que puede tener valor o no

//Optional Binding
if let nombre = name{   //Crea una variable solo si "nombre" tiene un valor
    print(nombre)
}else{
    print("No hay valor")
}

//desenboltura forzada
var name2 = name!   //Solo si estamos seguros que hay un dato

