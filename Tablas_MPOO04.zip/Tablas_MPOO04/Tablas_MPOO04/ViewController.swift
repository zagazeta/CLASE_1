//
//  ViewController.swift
//  Tablas_MPOO04
//
//  Created by Macbook on 2/26/19.
//  Copyright © 2019 dixLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    @IBOutlet weak var tabla: UITableView!
    
    var alumnos: [String] = ["Bricia", "Pedro", "Jule", "Luis", "Martin", "Valentina"]
    
    

    override func viewDidLoad(){
        super.viewDidLoad()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumnos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
    
        cell.backgroundColor = .blue
        cell.textLabel!.text = alumnos[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //print (indexPath.row)
        let optionMenu = UIAlertController(title: "Reprobando alumnos", message: "¿Desea reprobar a este alumno?", preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: "cancelar", style: .cancel, handler: nil)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (action:
            UIAlertAction) -> Void in
            let cell = tableView.cellForRow(at: indexPath)
            
            if (cell?.accessoryType.rawValue ==  0){
            
            cell?.accessoryType = .checkmark
            }else{
                cell?.accessoryType = .none
            }
            self.performSegue(withIdentifier: "toSecondView", sender: self)
        }

        optionMenu.addAction(okAction)
        optionMenu.addAction(cancelAction)
        
        present(optionMenu, animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //fUNCION HERENDADA
        if (segue.identifier == "toSecondView"){
            
            let indexPath = tabla.indexPathForSelectedRow
            let secondView = segue.destination as? SecondViewController
            secondView?.dato = alumnos[(indexPath?.row)!]
        
    }
    }
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        print(identifier)
        return false 
    }


}

