//
//  ViewController.swift
//  Mpoo-fire
//
//  Created by Macbook on 4/2/19.
//  Copyright © 2019 dixLab. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class ViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func registerUser(_ sender: UIButton) {
        
      guard let emailUser = email.text, emailUser != "",
        let passUser = password.text, passUser != "" else{
            print ("Datos no validos")
            return
    }
        Auth.auth().createUser(withEmail: emailUser, password: passUser) { (user, error) in
            if let error = error{
                print("no se pudo crear el usuario")
                print(error.localizedDescription)
                return
            }
            print("Usuario creado: " + user!.user.uid)
        }
}
    
}
