import UIKit

class Persona {
    var nombre: String
    var edad: Int
    var sexo: String
    
    func comer (){
    print("\(nombre) Esta comiendo")
}

    func dormir (){
        print("\(nombre) Esta durmiendo")
}

    func reproducir(){
        print("\(nombre) Se esta reproduciendo")
}

    //Inicializador
    init(nombre: String, edad: Int, sexo: String) {
        self.nombre = nombre
        self.edad = edad
        self.sexo = sexo
    }
}



var Juan = Persona(nombre: "Juan", edad: 20, sexo: "Diario")
Juan.nombre
Juan.dormir()
Juan.comer()
Juan.reproducir()

var Victor = Persona(nombre: "Victor", edad:5, sexo: "Hombre")
Juan.nombre
Victor.nombre

Juan = Victor
Juan.nombre

struct alumno{
    var nombre:String
    var noCuenta: String
    var sexo: String
    var promedio: Double
    
    func estudiar(){
        print("\(nombre) esta estudiando")
    }
    
    func comer(){
        print("\(nombre) esta comiendo (si puede)")
    }
    
    init(nombre: String, noCuenta: String, promedio: Double) {
        self.nombre = nombre
        self.noCuenta = noCuenta
        self.sexo = "Sexo"
        self.promedio = promedio
    }
}

let carlos = alumno(nombre: "Carlos", noCuenta: "7654783456", promedio: 8.0)

carlos.comer()

var Lucia = alumno(nombre: "Lucia", noCuenta: "12345678", promedio: 10.0)

Lucia.sexo


class Empleado: Persona{
    var Puesto: String
    var horasDeTrabajo:Int
    
    init(nombre: String, sexo: String, edad: Int, puesto:String, horasDeTrabajo: Int) {
        self.Puesto = puesto
        self.horasDeTrabajo = horasDeTrabajo
        super.init (nombre: nombre, edad: edad, sexo: sexo)
    }
    override func comer() {
        super.comer()
        print("Ahora es godin")
    }
}

let Godin = Empleado (nombre: "Carlos", sexo: "Mucho", edad: 19, puesto: "CEO", horasDeTrabajo: 1)

Godin.nombre
Godin.comer()
