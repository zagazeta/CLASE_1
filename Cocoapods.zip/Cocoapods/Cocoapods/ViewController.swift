//
//  ViewController.swift
//  Cocoapods
//
//  Created by Macbook on 3/28/19.
//  Copyright © 2019 dixLab. All rights reserved.
//

import UIKit
import Lottie

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let animation = LOTAnimationView(name: "4883-beer-icon")
        animation.loopAnimation = true
        animation.frame = view.frame
        self.view.addSubview(animation)
        animation.play()
        
        
        
//        animation.frame = CGRect(x: 0, y: 0, width: 400, height: 400)
//        animation.center = self.view.center
//        animation.contentMode = .scaleAspectFill
//        view.addSubview(animation)
    }


}

