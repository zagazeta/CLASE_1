//
//  ViewController.swift
//  Usuario
//
//created by Usuario on 28/02/19.
//Copyright © 2019 unam fca. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func viewDidAppear(_ animated: Bool) {
        let logged = UserDefaults.standard.bool(forKey: "logged");
        if(!logged)
        {
            self.performSegue(withIdentifier: "loginview", sender: self)
            
        }
    }
    
    @IBAction func Cerrar(_ sender: Any) {
        UserDefaults.standard.set(false, forKey: "logged")
        UserDefaults.standard.synchronize()
        self.performSegue(withIdentifier: "loginview", sender: self)
    }
    

}

